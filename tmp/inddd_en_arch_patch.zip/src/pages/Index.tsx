import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useI18n } from "@/i18n/I18nProvider";

const Index = () => {
  const { user } = useAuth();
  const { path } = useI18n();

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-foreground">QueueLine</h1>
        <p className="text-lg text-muted-foreground max-w-md">
          Clinic queue & visit-flow management — one live operational truth for your clinic day.
        </p>
        <div className="flex gap-3 justify-center pt-4">
          {user ? (
            <Button asChild>
              <Link to={path("/console")}>Open Console</Link>
            </Button>
          ) : (
            <Button asChild>
              <Link to={path("/login")}>Sign In</Link>
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Index;
