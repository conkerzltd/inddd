import TopNav from "@/components/marketing/TopNav";
import HeroSearch from "@/components/marketing/HeroSearch";
import ValueProps from "@/components/marketing/ValueProps";
import SpecialtyGrid from "@/components/marketing/SpecialtyGrid";
import HowItWorks from "@/components/marketing/HowItWorks";
import ClinicCta from "@/components/marketing/ClinicCta";
import Faq from "@/components/marketing/Faq";
import Footer from "@/components/marketing/Footer";
import Seo from "@/components/seo/Seo";
import { buildWebsiteSchema } from "@/components/seo/schema";
import { cities, specialties } from "@/data/directory";
import { PUBLIC_BASE_URL } from "@/config/publicBaseUrl";
import { useI18n } from "@/i18n/I18nProvider";

const MarketingHome = () => {
  const baseUrl = PUBLIC_BASE_URL;
  const { dir, t, path } = useI18n();

  const navLabels = {
    findDoctor: t("nav.findDoctor"),
    specialties: t("nav.specialties"),
    forClinics: t("nav.forClinics"),
    howItWorks: t("nav.howItWorks"),
    faq: t("nav.faq"),
    ctaPrimary: t("nav.ctaPrimary"),
    ctaSecondary: t("nav.ctaSecondary"),
    language: t("nav.language"),
  };

  const heroLabels = {
    title: t("hero.title"),
    subtitle: t("hero.subtitle"),
    helper: t("hero.helper"),
    searchCta: t("hero.searchCta"),
    specialtyLabel: t("hero.specialtyLabel"),
    cityLabel: t("hero.cityLabel"),
    areaLabel: t("hero.areaLabel"),
    doctorLabel: t("hero.doctorLabel"),
    note: t("hero.note"),
    patientLinkTitle: t("hero.patientLinkTitle"),
    patientLinkBody: t("hero.patientLinkBody"),
  };

  return (
    <div className="min-h-screen bg-background" dir={dir}>
      <Seo
        title="inddd | Patients-first clinic queues"
        description="Patients-first queue clarity for clinics. See your turn and ETA range before you arrive."
        canonical={`${baseUrl}${path("/")}`}
        schema={buildWebsiteSchema(baseUrl)}
      />

      <TopNav labels={navLabels} />

      <main>
        <div id="find-doctor">
          <HeroSearch specialties={specialties} cities={cities} labels={heroLabels} />
        </div>
        <ValueProps />
        <SpecialtyGrid
          specialties={specialties}
          title={t("sections.popularSpecialties.title")}
          subtitle={t("sections.popularSpecialties.subtitle")}
        />
        <HowItWorks />
        <ClinicCta />
        <Faq />
      </main>

      <Footer />
    </div>
  );
};

export default MarketingHome;
