import React, { createContext, useContext, useEffect, useMemo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import en from "@/locales/en.json";
import ar from "@/locales/ar.json";
import { DEFAULT_LOCALE, LOCALE_PREFIX, type Locale } from "./config";

type Messages = Record<string, any>;

type I18nContextValue = {
  locale: Locale;
  dir: "ltr" | "rtl";
  prefix: string;
  t: (key: string, fallback?: string) => string;
  /**
   * Builds a locale-aware route path.
   * Examples (when locale=en): path("/") => "/en", path("/doctors") => "/en/doctors"
   */
  path: (routePath: string) => string;
  /** Navigate to the same page in the other locale. */
  switchLocale: () => void;
  /** Navigate to the same page in a specific locale. */
  setLocale: (next: Locale) => void;
};

const I18nContext = createContext<I18nContextValue | null>(null);

const MESSAGES: Record<Locale, Messages> = {
  en: en as Messages,
  ar: ar as Messages,
};

function isEnPath(pathname: string) {
  return pathname === "/en" || pathname.startsWith("/en/");
}

function resolveLocale(pathname: string): Locale {
  if (isEnPath(pathname)) return "en";
  return DEFAULT_LOCALE;
}

function stripLocalePrefix(pathname: string): string {
  if (pathname === "/en") return "/";
  if (pathname.startsWith("/en/")) return pathname.slice(3);
  return pathname;
}

function getByKey(messages: Messages, key: string): unknown {
  return key.split(".").reduce((acc: any, part) => (acc ? acc[part] : undefined), messages);
}

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const { pathname, search, hash } = useLocation();
  const navigate = useNavigate();

  const locale = resolveLocale(pathname);
  const prefix = LOCALE_PREFIX[locale];
  const dir: "ltr" | "rtl" = locale === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    // Keep the root HTML element consistent for SEO and correct layout.
    document.documentElement.lang = locale;
    document.documentElement.dir = dir;
  }, [locale, dir]);

  const t = useMemo(() => {
    return (key: string, fallback?: string) => {
      const value = getByKey(MESSAGES[locale], key);
      if (typeof value === "string") return value;

      // Fallback to English if Arabic isn't filled yet.
      const enValue = getByKey(MESSAGES.en, key);
      if (typeof enValue === "string") return enValue;

      return fallback ?? key;
    };
  }, [locale]);

  const path = useMemo(() => {
    return (routePath: string) => {
      const normalized = routePath.startsWith("/") ? routePath : `/${routePath}`;
      if (normalized === "/") return prefix || "/";
      return `${prefix}${normalized}` || normalized;
    };
  }, [prefix]);

  const setLocale = (next: Locale) => {
    const base = stripLocalePrefix(pathname);
    const nextPrefix = LOCALE_PREFIX[next];
    const nextPath = (nextPrefix + (base === "/" ? "" : base)) || "/";
    navigate(`${nextPath}${search}${hash}`, { replace: true });
  };

  const switchLocale = () => setLocale(locale === "en" ? "ar" : "en");

  const value = useMemo<I18nContextValue>(
    () => ({ locale, dir, prefix, t, path, switchLocale, setLocale }),
    [locale, dir, prefix, t, path]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}
