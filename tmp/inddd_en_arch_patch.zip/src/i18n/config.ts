export type Locale = "en" | "ar";

/**
 * Phase A (English-first): keep DEFAULT_LOCALE = "en".
 * Phase B (Arabic-default): change DEFAULT_LOCALE to "ar" (and fill ar.json + Arabic directory data).
 */
export const DEFAULT_LOCALE: Locale = "en";

/**
 * URL prefix strategy:
 * - English lives under /en
 * - Arabic is the default (no prefix) once DEFAULT_LOCALE becomes "ar"
 */
export const LOCALE_PREFIX: Record<Locale, string> = {
  en: "/en",
  ar: "",
};

export const LOCALES: Locale[] = ["en", "ar"]; // keep "ar" for later; UI can hide switch until ready.

/** Set to true only when Arabic UI + data is production-ready. */
export const ENABLE_LANGUAGE_SWITCH = false;
