// Auto-generated English directory data for inddd (Vezeeta-style search UI).
// Source: translated from repo seed lists (specialties_seed_v1.csv, locations_seed.csv) with common Egypt medical-app naming conventions.

export type Specialty = {
  name: string;
  slug: string;
  icon: string;
  intro: string;
};

export type Area = {
  name: string;
  slug: string;
};

export type City = {
  name: string;
  slug: string;
  areas: Area[];
};

export const specialties: Specialty[] = [
  {
    "name": "Dermatology (Skin)",
    "slug": "dermatology",
    "icon": "sparkles",
    "intro": "Find verified clinics and specialists for Dermatology with transparent waiting times."
  },
  {
    "name": "Dentistry (Teeth)",
    "slug": "dentistry",
    "icon": "tooth",
    "intro": "Find verified clinics and specialists for Dentistry with transparent waiting times."
  },
  {
    "name": "Psychiatry (Mental, Emotional or Behavioral Disorders)",
    "slug": "psychiatry",
    "icon": "mind",
    "intro": "Find verified clinics and specialists for Psychiatry with transparent waiting times."
  },
  {
    "name": "Pediatrics and New Born (Child)",
    "slug": "pediatrics-and-new-born",
    "icon": "baby",
    "intro": "Find verified clinics and specialists for Pediatrics and New Born with transparent waiting times."
  },
  {
    "name": "Neurology (Brain & Nerves)",
    "slug": "neurology",
    "icon": "brain",
    "intro": "Find verified clinics and specialists for Neurology with transparent waiting times."
  },
  {
    "name": "Orthopedics (Bones)",
    "slug": "orthopedics",
    "icon": "bone",
    "intro": "Find verified clinics and specialists for Orthopedics with transparent waiting times."
  },
  {
    "name": "Gynaecology and Infertility",
    "slug": "gynaecology-and-infertility",
    "icon": "heart-pulse",
    "intro": "Find verified clinics and specialists for Gynaecology and Infertility with transparent waiting times."
  },
  {
    "name": "Ear, Nose and Throat",
    "slug": "ear-nose-and-throat",
    "icon": "ear",
    "intro": "Find verified clinics and specialists for Ear, Nose and Throat with transparent waiting times."
  },
  {
    "name": "Cardiology and Vascular Disease (Heart)",
    "slug": "cardiology-and-vascular-disease",
    "icon": "heart",
    "intro": "Find verified clinics and specialists for Cardiology and Vascular Disease with transparent waiting times."
  },
  {
    "name": "Hematology",
    "slug": "hematology",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Hematology with transparent waiting times."
  },
  {
    "name": "Internal Medicine",
    "slug": "internal-medicine",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Internal Medicine with transparent waiting times."
  },
  {
    "name": "Dietitian and Nutrition",
    "slug": "dietitian-and-nutrition",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Dietitian and Nutrition with transparent waiting times."
  },
  {
    "name": "Pediatric Surgery",
    "slug": "pediatric-surgery",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Pediatric Surgery with transparent waiting times."
  },
  {
    "name": "Oncology Surgery",
    "slug": "oncology-surgery",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Oncology Surgery with transparent waiting times."
  },
  {
    "name": "Vascular Surgery",
    "slug": "vascular-surgery",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Vascular Surgery with transparent waiting times."
  },
  {
    "name": "Plastic Surgery",
    "slug": "plastic-surgery",
    "icon": "sparkles",
    "intro": "Find verified clinics and specialists for Plastic Surgery with transparent waiting times."
  },
  {
    "name": "Obesity and Laparoscopic Surgery",
    "slug": "obesity-and-laparoscopic-surgery",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Obesity and Laparoscopic Surgery with transparent waiting times."
  },
  {
    "name": "General Surgery",
    "slug": "general-surgery",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for General Surgery with transparent waiting times."
  },
  {
    "name": "Spinal Surgery",
    "slug": "spinal-surgery",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Spinal Surgery with transparent waiting times."
  },
  {
    "name": "Cardiology and Thoracic Surgery (Heart & Chest)",
    "slug": "cardiology-and-thoracic-surgery",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Cardiology and Thoracic Surgery with transparent waiting times."
  },
  {
    "name": "Neurosurgery",
    "slug": "neurosurgery",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Neurosurgery with transparent waiting times."
  },
  {
    "name": "Gastroenterology and Endoscopy",
    "slug": "gastroenterology-and-endoscopy",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Gastroenterology and Endoscopy with transparent waiting times."
  },
  {
    "name": "Allergy and Immunology (Sensitivity and Immunity)",
    "slug": "allergy-and-immunology",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Allergy and Immunology with transparent waiting times."
  },
  {
    "name": "IVF and Infertility",
    "slug": "ivf-and-infertility",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for IVF and Infertility with transparent waiting times."
  },
  {
    "name": "Andrology and Male Infertility",
    "slug": "andrology-and-male-infertility",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Andrology and Male Infertility with transparent waiting times."
  },
  {
    "name": "Rheumatology",
    "slug": "rheumatology",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Rheumatology with transparent waiting times."
  },
  {
    "name": "Diabetes and Endocrinology",
    "slug": "diabetes-and-endocrinology",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Diabetes and Endocrinology with transparent waiting times."
  },
  {
    "name": "Audiology",
    "slug": "audiology",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Audiology with transparent waiting times."
  },
  {
    "name": "Chest and Respiratory",
    "slug": "chest-and-respiratory",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Chest and Respiratory with transparent waiting times."
  },
  {
    "name": "Family Medicine",
    "slug": "family-medicine",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Family Medicine with transparent waiting times."
  },
  {
    "name": "Geriatrics",
    "slug": "geriatrics",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Geriatrics with transparent waiting times."
  },
  {
    "name": "Veterinary",
    "slug": "veterinary",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Veterinary with transparent waiting times."
  },
  {
    "name": "Osteopathy",
    "slug": "osteopathy",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Osteopathy with transparent waiting times."
  },
  {
    "name": "Pain Management",
    "slug": "pain-management",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Pain Management with transparent waiting times."
  },
  {
    "name": "Physiotherapy and Sport Injuries",
    "slug": "physiotherapy-and-sport-injuries",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Physiotherapy and Sport Injuries with transparent waiting times."
  },
  {
    "name": "Ophthalmology",
    "slug": "ophthalmology",
    "icon": "eye",
    "intro": "Find verified clinics and specialists for Ophthalmology with transparent waiting times."
  },
  {
    "name": "Hepatology",
    "slug": "hepatology",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Hepatology with transparent waiting times."
  },
  {
    "name": "Nephrology",
    "slug": "nephrology",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Nephrology with transparent waiting times."
  },
  {
    "name": "Urology",
    "slug": "urology",
    "icon": "droplet",
    "intro": "Find verified clinics and specialists for Urology with transparent waiting times."
  },
  {
    "name": "Phoniatrics",
    "slug": "phoniatrics",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for Phoniatrics with transparent waiting times."
  },
  {
    "name": "General Practice",
    "slug": "general-practice",
    "icon": "stethoscope",
    "intro": "Find verified clinics and specialists for General Practice with transparent waiting times."
  }
] as Specialty[];

export const cities: City[] = [
  {
    "name": "Cairo",
    "slug": "cairo",
    "areas": [
      {
        "name": "10th of Ramadan City",
        "slug": "10th-of-ramadan-city"
      },
      {
        "name": "Abbassia",
        "slug": "abbassia"
      },
      {
        "name": "Ain Shams",
        "slug": "ain-shams"
      },
      {
        "name": "Al Rehab",
        "slug": "al-rehab"
      },
      {
        "name": "Badr City",
        "slug": "badr-city"
      },
      {
        "name": "Bulaq",
        "slug": "bulaq"
      },
      {
        "name": "Dar El Salam",
        "slug": "dar-el-salam"
      },
      {
        "name": "Downtown",
        "slug": "downtown"
      },
      {
        "name": "El Marg",
        "slug": "el-marg"
      },
      {
        "name": "El Matareya",
        "slug": "el-matareya"
      },
      {
        "name": "El Salam City",
        "slug": "el-salam-city"
      },
      {
        "name": "El Shorouk",
        "slug": "el-shorouk"
      },
      {
        "name": "El Zeitoun",
        "slug": "el-zeitoun"
      },
      {
        "name": "Hadayek El Maadi",
        "slug": "hadayek-el-maadi"
      },
      {
        "name": "Hadayek El Qobba",
        "slug": "hadayek-el-qobba"
      },
      {
        "name": "Hadayek Helwan",
        "slug": "hadayek-helwan"
      },
      {
        "name": "Heliopolis",
        "slug": "heliopolis"
      },
      {
        "name": "Helwan",
        "slug": "helwan"
      },
      {
        "name": "Katameya",
        "slug": "katameya"
      },
      {
        "name": "Maadi",
        "slug": "maadi"
      },
      {
        "name": "Madinaty",
        "slug": "madinaty"
      },
      {
        "name": "Manial",
        "slug": "manial"
      },
      {
        "name": "Mokattam",
        "slug": "mokattam"
      },
      {
        "name": "Mostakbal City",
        "slug": "mostakbal-city"
      },
      {
        "name": "Nasr City",
        "slug": "nasr-city"
      },
      {
        "name": "New Cairo",
        "slug": "new-cairo"
      },
      {
        "name": "New Nozha",
        "slug": "new-nozha"
      },
      {
        "name": "Obour City",
        "slug": "obour-city"
      },
      {
        "name": "Old Cairo",
        "slug": "old-cairo"
      },
      {
        "name": "Sayeda Zeinab",
        "slug": "sayeda-zeinab"
      },
      {
        "name": "Shubra",
        "slug": "shubra"
      },
      {
        "name": "Shubra El Kheima",
        "slug": "shubra-el-kheima"
      },
      {
        "name": "Zamalek",
        "slug": "zamalek"
      }
    ]
  },
  {
    "name": "Giza",
    "slug": "giza",
    "areas": [
      {
        "name": "6th of October City",
        "slug": "6th-of-october-city"
      },
      {
        "name": "Abu Nomros",
        "slug": "abu-nomros"
      },
      {
        "name": "Agouza",
        "slug": "agouza"
      },
      {
        "name": "Atfih",
        "slug": "atfih"
      },
      {
        "name": "Ayat",
        "slug": "ayat"
      },
      {
        "name": "Badrasheen",
        "slug": "badrasheen"
      },
      {
        "name": "Bulaq El Dakrour",
        "slug": "bulaq-el-dakrour"
      },
      {
        "name": "Dokki",
        "slug": "dokki"
      },
      {
        "name": "El Saff",
        "slug": "el-saff"
      },
      {
        "name": "Faisal",
        "slug": "faisal"
      },
      {
        "name": "Giza Square",
        "slug": "giza-square"
      },
      {
        "name": "Hadayek Al Ahram",
        "slug": "hadayek-al-ahram"
      },
      {
        "name": "Hadayek October",
        "slug": "hadayek-october"
      },
      {
        "name": "Haram",
        "slug": "haram"
      },
      {
        "name": "Hawamdeya",
        "slug": "hawamdeya"
      },
      {
        "name": "Imbaba",
        "slug": "imbaba"
      },
      {
        "name": "Kerdasa",
        "slug": "kerdasa"
      },
      {
        "name": "Manshaat El Qanater",
        "slug": "manshaat-el-qanater"
      },
      {
        "name": "Mohandessin",
        "slug": "mohandessin"
      },
      {
        "name": "New Giza",
        "slug": "new-giza"
      },
      {
        "name": "Oseem",
        "slug": "oseem"
      },
      {
        "name": "Sheikh Zayed City",
        "slug": "sheikh-zayed-city"
      }
    ]
  },
  {
    "name": "Alexandria",
    "slug": "alexandria",
    "areas": [
      {
        "name": "Abu Qir",
        "slug": "abu-qir"
      },
      {
        "name": "Agamy",
        "slug": "agamy"
      },
      {
        "name": "Amreya",
        "slug": "amreya"
      },
      {
        "name": "Asafra",
        "slug": "asafra"
      },
      {
        "name": "Azarita",
        "slug": "azarita"
      },
      {
        "name": "Bahary",
        "slug": "bahary"
      },
      {
        "name": "Bakos",
        "slug": "bakos"
      },
      {
        "name": "Bolkly",
        "slug": "bolkly"
      },
      {
        "name": "Borg El Arab",
        "slug": "borg-el-arab"
      },
      {
        "name": "Camp Caesar",
        "slug": "camp-caesar"
      },
      {
        "name": "Cleopatra",
        "slug": "cleopatra"
      },
      {
        "name": "Fleming",
        "slug": "fleming"
      },
      {
        "name": "Fouad Street",
        "slug": "fouad-street"
      },
      {
        "name": "Gianaclis",
        "slug": "gianaclis"
      },
      {
        "name": "Gleem",
        "slug": "gleem"
      },
      {
        "name": "Ibrahimiya",
        "slug": "ibrahimiya"
      },
      {
        "name": "Kafr Abdo",
        "slug": "kafr-abdo"
      },
      {
        "name": "King Mariout",
        "slug": "king-mariout"
      },
      {
        "name": "Laurent",
        "slug": "laurent"
      },
      {
        "name": "Mandara",
        "slug": "mandara"
      },
      {
        "name": "Mansheya",
        "slug": "mansheya"
      },
      {
        "name": "Miami",
        "slug": "miami"
      },
      {
        "name": "Moharam Bek",
        "slug": "moharam-bek"
      },
      {
        "name": "Montaza",
        "slug": "montaza"
      },
      {
        "name": "Mostafa Kamel",
        "slug": "mostafa-kamel"
      },
      {
        "name": "Raml Station",
        "slug": "raml-station"
      },
      {
        "name": "Roushdy",
        "slug": "roushdy"
      },
      {
        "name": "Saba Pasha",
        "slug": "saba-pasha"
      },
      {
        "name": "San Stefano",
        "slug": "san-stefano"
      },
      {
        "name": "Seyouf",
        "slug": "seyouf"
      },
      {
        "name": "Shatby",
        "slug": "shatby"
      },
      {
        "name": "Sidi Bishr",
        "slug": "sidi-bishr"
      },
      {
        "name": "Sidi Gaber",
        "slug": "sidi-gaber"
      },
      {
        "name": "Smouha",
        "slug": "smouha"
      },
      {
        "name": "Sporting",
        "slug": "sporting"
      },
      {
        "name": "Victoria",
        "slug": "victoria"
      },
      {
        "name": "Wardian",
        "slug": "wardian"
      },
      {
        "name": "Zezenia",
        "slug": "zezenia"
      }
    ]
  },
  {
    "name": "Qalyubia",
    "slug": "qalyubia",
    "areas": [
      {
        "name": "Banha",
        "slug": "banha"
      },
      {
        "name": "Banha — Kafr El Gzar",
        "slug": "banha-kafr-el-gzar"
      },
      {
        "name": "Banha — Mit El Hofiin",
        "slug": "banha-mit-el-hofiin"
      },
      {
        "name": "El Khanka",
        "slug": "el-khanka"
      },
      {
        "name": "El Khanka — Abu Zbl",
        "slug": "el-khanka-abu-zbl"
      },
      {
        "name": "El Khanka — El Gbl El Asfr",
        "slug": "el-khanka-el-gbl-el-asfr"
      },
      {
        "name": "El Qnatr El Khiria",
        "slug": "el-qnatr-el-khiria"
      },
      {
        "name": "El Qnatr El Khiria — Basos",
        "slug": "el-qnatr-el-khiria-basos"
      },
      {
        "name": "El Qnatr El Khiria — Shlqan",
        "slug": "el-qnatr-el-khiria-shlqan"
      },
      {
        "name": "Kafr Shkr",
        "slug": "kafr-shkr"
      },
      {
        "name": "Kafr Shkr — Mhita",
        "slug": "kafr-shkr-mhita"
      },
      {
        "name": "Qalyub",
        "slug": "qalyub"
      },
      {
        "name": "Qalyub — Blqs",
        "slug": "qalyub-blqs"
      },
      {
        "name": "Qalyub — Nai",
        "slug": "qalyub-nai"
      },
      {
        "name": "Tokh",
        "slug": "tokh"
      },
      {
        "name": "Tokh — El Dir",
        "slug": "tokh-el-dir"
      },
      {
        "name": "Tokh — Mshthr",
        "slug": "tokh-mshthr"
      }
    ]
  },
  {
    "name": "El-Sharqia",
    "slug": "el-sharqia",
    "areas": [
      {
        "name": "Abu Hammad",
        "slug": "abu-hammad"
      },
      {
        "name": "Abu Hammad — Beni Aiob",
        "slug": "abu-hammad-beni-aiob"
      },
      {
        "name": "Abu Hammad — El Swaaf Hmad",
        "slug": "abu-hammad-el-swaaf-hmad"
      },
      {
        "name": "Awlad Saqr",
        "slug": "awlad-saqr"
      },
      {
        "name": "Awlad Saqr — El Sofia Skana Aql",
        "slug": "awlad-saqr-el-sofia-skana-aql"
      },
      {
        "name": "Bilbeis",
        "slug": "bilbeis"
      },
      {
        "name": "Bilbeis — El Ktiba",
        "slug": "bilbeis-el-ktiba"
      },
      {
        "name": "Bilbeis — El Salm",
        "slug": "bilbeis-el-salm"
      },
      {
        "name": "Dirb Ngm",
        "slug": "dirb-ngm"
      },
      {
        "name": "Dirb Ngm — Oqraha",
        "slug": "dirb-ngm-oqraha"
      },
      {
        "name": "El Hsinia",
        "slug": "el-hsinia"
      },
      {
        "name": "El Hsinia — Qsasin El Shrq",
        "slug": "el-hsinia-qsasin-el-shrq"
      },
      {
        "name": "El Hsinia — Smakin El Shrq",
        "slug": "el-hsinia-smakin-el-shrq"
      },
      {
        "name": "El-Ibrahimiya",
        "slug": "el-ibrahimiya"
      },
      {
        "name": "El-Ibrahimiya — Oqraha",
        "slug": "el-ibrahimiya-oqraha"
      },
      {
        "name": "Faqous",
        "slug": "faqous"
      },
      {
        "name": "Faqous — El Roda",
        "slug": "faqous-el-roda"
      },
      {
        "name": "Faqous — Manshaat Mr Abu",
        "slug": "faqous-manshaat-mr-abu"
      },
      {
        "name": "Hehia",
        "slug": "hehia"
      },
      {
        "name": "Hehia — El Mhdia Oqraha",
        "slug": "hehia-el-mhdia-oqraha"
      },
      {
        "name": "Kafr Saqr",
        "slug": "kafr-saqr"
      },
      {
        "name": "Kafr Saqr — Oqraha",
        "slug": "kafr-saqr-oqraha"
      },
      {
        "name": "Mashtoul El-Souk",
        "slug": "mashtoul-el-souk"
      },
      {
        "name": "Mashtoul El-Souk — Oqraha",
        "slug": "mashtoul-el-souk-oqraha"
      },
      {
        "name": "Minya El-Qamh",
        "slug": "minya-el-qamh"
      },
      {
        "name": "Minya El-Qamh — El Gdida",
        "slug": "minya-el-qamh-el-gdida"
      },
      {
        "name": "Minya El-Qamh — El Sdiin",
        "slug": "minya-el-qamh-el-sdiin"
      },
      {
        "name": "Zagazig",
        "slug": "zagazig"
      },
      {
        "name": "Zagazig — Bhnbai",
        "slug": "zagazig-bhnbai"
      },
      {
        "name": "Zagazig — Hria Rzna",
        "slug": "zagazig-hria-rzna"
      },
      {
        "name": "Zagazig — Shiba El Nkaria",
        "slug": "zagazig-shiba-el-nkaria"
      }
    ]
  },
  {
    "name": "El-Dakahlia",
    "slug": "el-dakahlia",
    "areas": [
      {
        "name": "Belqas",
        "slug": "belqas"
      },
      {
        "name": "Belqas — Abu Blha",
        "slug": "belqas-abu-blha"
      },
      {
        "name": "Belqas — Khams",
        "slug": "belqas-khams"
      },
      {
        "name": "Dekernes",
        "slug": "dekernes"
      },
      {
        "name": "Dekernes — Dimshlt",
        "slug": "dekernes-dimshlt"
      },
      {
        "name": "Dekernes — Mit El Sodan",
        "slug": "dekernes-mit-el-sodan"
      },
      {
        "name": "El Mnzla",
        "slug": "el-mnzla"
      },
      {
        "name": "El Mnzla — El Bsrat",
        "slug": "el-mnzla-el-bsrat"
      },
      {
        "name": "El Mnzla — El Gmalia Da Ai Mnfsla",
        "slug": "el-mnzla-el-gmalia-da-ai-mnfsla"
      },
      {
        "name": "El Snbaloin",
        "slug": "el-snbaloin"
      },
      {
        "name": "El Snbaloin — Bstaoisi",
        "slug": "el-snbaloin-bstaoisi"
      },
      {
        "name": "El Snbaloin — Tokh El Aqalm",
        "slug": "el-snbaloin-tokh-el-aqalm"
      },
      {
        "name": "Mansoura",
        "slug": "mansoura"
      },
      {
        "name": "Mansoura — Bdin",
        "slug": "mansoura-bdin"
      },
      {
        "name": "Mansoura — Shha",
        "slug": "mansoura-shha"
      },
      {
        "name": "Mansoura — Tlbana",
        "slug": "mansoura-tlbana"
      },
      {
        "name": "Mit Ghamr",
        "slug": "mit-ghamr"
      },
      {
        "name": "Mit Ghamr — Dmas",
        "slug": "mit-ghamr-dmas"
      },
      {
        "name": "Mit Ghamr — Shrgt El Kubra",
        "slug": "mit-ghamr-shrgt-el-kubra"
      },
      {
        "name": "Sherbin",
        "slug": "sherbin"
      },
      {
        "name": "Sherbin — Kafr El Okala",
        "slug": "sherbin-kafr-el-okala"
      },
      {
        "name": "Sherbin — Ras El Khlig",
        "slug": "sherbin-ras-el-khlig"
      },
      {
        "name": "Talkha",
        "slug": "talkha"
      },
      {
        "name": "Talkha — Dmira",
        "slug": "talkha-dmira"
      },
      {
        "name": "Talkha — Mit El Krma",
        "slug": "talkha-mit-el-krma"
      }
    ]
  },
  {
    "name": "El-Beheira",
    "slug": "el-beheira",
    "areas": [
      {
        "name": "Abu Hms",
        "slug": "abu-hms"
      },
      {
        "name": "Abu Hms — Blqtr",
        "slug": "abu-hms-blqtr"
      },
      {
        "name": "Abu Hms — Dmsna",
        "slug": "abu-hms-dmsna"
      },
      {
        "name": "Badr",
        "slug": "badr"
      },
      {
        "name": "Badr — Zrai Astsalh El Mshro",
        "slug": "badr-zrai-astsalh-el-mshro"
      },
      {
        "name": "Damanhur",
        "slug": "damanhur"
      },
      {
        "name": "Damanhur — Abu El Rish",
        "slug": "damanhur-abu-el-rish"
      },
      {
        "name": "Damanhur — Zhor El Amra",
        "slug": "damanhur-zhor-el-amra"
      },
      {
        "name": "Edko",
        "slug": "edko"
      },
      {
        "name": "Edko — Abu Bndora",
        "slug": "edko-abu-bndora"
      },
      {
        "name": "Edko — El Dmiati",
        "slug": "edko-el-dmiati"
      },
      {
        "name": "El-Delengat",
        "slug": "el-delengat"
      },
      {
        "name": "El-Delengat — El Bstan",
        "slug": "el-delengat-el-bstan"
      },
      {
        "name": "El-Delengat — Tiba",
        "slug": "el-delengat-tiba"
      },
      {
        "name": "El-Mahmoudiya",
        "slug": "el-mahmoudiya"
      },
      {
        "name": "El-Mahmoudiya — Abiana",
        "slug": "el-mahmoudiya-abiana"
      },
      {
        "name": "El-Mahmoudiya — Srnbai",
        "slug": "el-mahmoudiya-srnbai"
      },
      {
        "name": "El-Rahmaniya",
        "slug": "el-rahmaniya"
      },
      {
        "name": "El-Rahmaniya — Boit",
        "slug": "el-rahmaniya-boit"
      },
      {
        "name": "El-Rahmaniya — Smkhrat",
        "slug": "el-rahmaniya-smkhrat"
      },
      {
        "name": "Itay El-Baroud",
        "slug": "itay-el-baroud"
      },
      {
        "name": "Itay El-Baroud — Abu Masoud",
        "slug": "itay-el-baroud-abu-masoud"
      },
      {
        "name": "Itay El-Baroud — Minya",
        "slug": "itay-el-baroud-minya"
      },
      {
        "name": "Kafr El-Dawwar",
        "slug": "kafr-el-dawwar"
      },
      {
        "name": "Kafr El-Dawwar — Sidi Ghazi",
        "slug": "kafr-el-dawwar-sidi-ghazi"
      },
      {
        "name": "Kafr El-Dawwar — Zhra",
        "slug": "kafr-el-dawwar-zhra"
      },
      {
        "name": "Kom Hmada",
        "slug": "kom-hmada"
      },
      {
        "name": "Kom Hmada — Qrtsa",
        "slug": "kom-hmada-qrtsa"
      },
      {
        "name": "Kom Hmada — Waaqd",
        "slug": "kom-hmada-waaqd"
      },
      {
        "name": "Rashid",
        "slug": "rashid"
      },
      {
        "name": "Rashid — El Gndia",
        "slug": "rashid-el-gndia"
      },
      {
        "name": "Rashid — Mhla El Amir",
        "slug": "rashid-mhla-el-amir"
      },
      {
        "name": "Shubrakhit",
        "slug": "shubrakhit"
      },
      {
        "name": "Shubrakhit — Knisa Aorin",
        "slug": "shubrakhit-knisa-aorin"
      },
      {
        "name": "Shubrakhit — Mhla Bshr",
        "slug": "shubrakhit-mhla-bshr"
      },
      {
        "name": "Wadi El-Natrun",
        "slug": "wadi-el-natrun"
      },
      {
        "name": "Wadi El-Natrun — El Hmra Shraoia Tbia Dhat",
        "slug": "wadi-el-natrun-el-hmra-shraoia-tbia-dhat"
      }
    ]
  },
  {
    "name": "Gharbia",
    "slug": "gharbia",
    "areas": [
      {
        "name": "Basyoun",
        "slug": "basyoun"
      },
      {
        "name": "El Mhla El Kubra",
        "slug": "el-mhla-el-kubra"
      },
      {
        "name": "El Ziat Kafr",
        "slug": "el-ziat-kafr"
      },
      {
        "name": "El-Santa",
        "slug": "el-santa"
      },
      {
        "name": "Qutour",
        "slug": "qutour"
      },
      {
        "name": "Tanta",
        "slug": "tanta"
      },
      {
        "name": "Zifta",
        "slug": "zifta"
      }
    ]
  },
  {
    "name": "Menoufia",
    "slug": "menoufia",
    "areas": [
      {
        "name": "Al-Bagour",
        "slug": "al-bagour"
      },
      {
        "name": "Al-Shohada",
        "slug": "al-shohada"
      },
      {
        "name": "Ashmoun",
        "slug": "ashmoun"
      },
      {
        "name": "El Sadat City",
        "slug": "el-sadat-city"
      },
      {
        "name": "Menouf",
        "slug": "menouf"
      },
      {
        "name": "Quesna",
        "slug": "quesna"
      },
      {
        "name": "Shibin El-Kom",
        "slug": "shibin-el-kom"
      },
      {
        "name": "Tala",
        "slug": "tala"
      }
    ]
  },
  {
    "name": "Kafr El Sheikh",
    "slug": "kafr-el-sheikh",
    "areas": [
      {
        "name": "Baltim",
        "slug": "baltim"
      },
      {
        "name": "Bial",
        "slug": "bial"
      },
      {
        "name": "Dsoq",
        "slug": "dsoq"
      },
      {
        "name": "El Riad",
        "slug": "el-riad"
      },
      {
        "name": "El Sheikh Kafr",
        "slug": "el-sheikh-kafr"
      },
      {
        "name": "El-Hamoul",
        "slug": "el-hamoul"
      },
      {
        "name": "Foh",
        "slug": "foh"
      },
      {
        "name": "Metobas",
        "slug": "metobas"
      },
      {
        "name": "Salm Sidi",
        "slug": "salm-sidi"
      }
    ]
  },
  {
    "name": "Damietta",
    "slug": "damietta",
    "areas": [
      {
        "name": "El Btikh Kafr",
        "slug": "el-btikh-kafr"
      },
      {
        "name": "El-Zarqa",
        "slug": "el-zarqa"
      },
      {
        "name": "Faraskur",
        "slug": "faraskur"
      },
      {
        "name": "New Damietta",
        "slug": "new-damietta"
      },
      {
        "name": "Ras El Bar",
        "slug": "ras-el-bar"
      },
      {
        "name": "Sd Kafr",
        "slug": "sd-kafr"
      }
    ]
  },
  {
    "name": "El-Ismailia",
    "slug": "el-ismailia",
    "areas": [
      {
        "name": "El Qntra Ghrb",
        "slug": "el-qntra-ghrb"
      },
      {
        "name": "El Qntra Shrq",
        "slug": "el-qntra-shrq"
      },
      {
        "name": "Faid",
        "slug": "faid"
      },
      {
        "name": "Soir Abu",
        "slug": "soir-abu"
      },
      {
        "name": "Tell El-Kebir",
        "slug": "tell-el-kebir"
      }
    ]
  },
  {
    "name": "Port Said",
    "slug": "port-said",
    "areas": [
      {
        "name": "Hi Borfad",
        "slug": "hi-borfad"
      },
      {
        "name": "Hi El Dwaahi",
        "slug": "hi-el-dwaahi"
      },
      {
        "name": "Hi El Mnakh",
        "slug": "hi-el-mnakh"
      },
      {
        "name": "Hi El Rb",
        "slug": "hi-el-rb"
      },
      {
        "name": "Hi El Shrq",
        "slug": "hi-el-shrq"
      }
    ]
  },
  {
    "name": "Suez",
    "slug": "suez",
    "areas": [
      {
        "name": "El Arbin",
        "slug": "el-arbin"
      },
      {
        "name": "El Gnain",
        "slug": "el-gnain"
      },
      {
        "name": "Faisal",
        "slug": "faisal"
      },
      {
        "name": "Taqa",
        "slug": "taqa"
      }
    ]
  },
  {
    "name": "North Sinai",
    "slug": "north-sinai",
    "areas": [
      {
        "name": "Bir El-Abd",
        "slug": "bir-el-abd"
      },
      {
        "name": "El Rish Mtabqa Ila",
        "slug": "el-rish-mtabqa-ila"
      },
      {
        "name": "El-Hasana",
        "slug": "el-hasana"
      },
      {
        "name": "Nekhel",
        "slug": "nekhel"
      },
      {
        "name": "Rafah",
        "slug": "rafah"
      },
      {
        "name": "Zoid El Sheikh",
        "slug": "zoid-el-sheikh"
      }
    ]
  },
  {
    "name": "South Sinai",
    "slug": "south-sinai",
    "areas": [
      {
        "name": "Dahab",
        "slug": "dahab"
      },
      {
        "name": "El Sheikh Shrm",
        "slug": "el-sheikh-shrm"
      },
      {
        "name": "El-Tor",
        "slug": "el-tor"
      },
      {
        "name": "Noib",
        "slug": "noib"
      },
      {
        "name": "Ras",
        "slug": "ras"
      },
      {
        "name": "Redis",
        "slug": "redis"
      },
      {
        "name": "Sant Katrin",
        "slug": "sant-katrin"
      },
      {
        "name": "Taba",
        "slug": "taba"
      },
      {
        "name": "Znima Abu",
        "slug": "znima-abu"
      }
    ]
  },
  {
    "name": "Red Sea",
    "slug": "red-sea",
    "areas": [
      {
        "name": "El Shaltin",
        "slug": "el-shaltin"
      },
      {
        "name": "El-Qoseir",
        "slug": "el-qoseir"
      },
      {
        "name": "Halayeb",
        "slug": "halayeb"
      },
      {
        "name": "Hurghada",
        "slug": "hurghada"
      },
      {
        "name": "Marsa Alam",
        "slug": "marsa-alam"
      },
      {
        "name": "Ras Ghareb",
        "slug": "ras-ghareb"
      },
      {
        "name": "Safaga",
        "slug": "safaga"
      }
    ]
  },
  {
    "name": "Matrouh",
    "slug": "matrouh",
    "areas": [
      {
        "name": "Brani Sidi",
        "slug": "brani-sidi"
      },
      {
        "name": "El Slom",
        "slug": "el-slom"
      },
      {
        "name": "El-Alamein",
        "slug": "el-alamein"
      },
      {
        "name": "El-Dabaa",
        "slug": "el-dabaa"
      },
      {
        "name": "El-Hammam",
        "slug": "el-hammam"
      },
      {
        "name": "El-Negila",
        "slug": "el-negila"
      },
      {
        "name": "Mersa Matruh",
        "slug": "mersa-matruh"
      },
      {
        "name": "Sioa",
        "slug": "sioa"
      }
    ]
  },
  {
    "name": "Fayoum",
    "slug": "fayoum",
    "areas": [
      {
        "name": "Ibshway",
        "slug": "ibshway"
      },
      {
        "name": "Itsa",
        "slug": "itsa"
      },
      {
        "name": "Sinnuris",
        "slug": "sinnuris"
      },
      {
        "name": "Tamia",
        "slug": "tamia"
      },
      {
        "name": "Youssef El-Siddiq",
        "slug": "youssef-el-siddiq"
      }
    ]
  },
  {
    "name": "Beni Suef",
    "slug": "beni-suef",
    "areas": [
      {
        "name": "Al-Wasta",
        "slug": "al-wasta"
      },
      {
        "name": "Biba",
        "slug": "biba"
      },
      {
        "name": "El Gdida Soif Beni",
        "slug": "el-gdida-soif-beni"
      },
      {
        "name": "Ihnasia",
        "slug": "ihnasia"
      },
      {
        "name": "Nasser",
        "slug": "nasser"
      },
      {
        "name": "Soif Beni",
        "slug": "soif-beni"
      },
      {
        "name": "Somosta",
        "slug": "somosta"
      }
    ]
  },
  {
    "name": "El-Minia",
    "slug": "el-minia",
    "areas": [
      {
        "name": "Abu Qurqas",
        "slug": "abu-qurqas"
      },
      {
        "name": "Abu Qurqas — Abioha",
        "slug": "abu-qurqas-abioha"
      },
      {
        "name": "Beni Mazar",
        "slug": "beni-mazar"
      },
      {
        "name": "Beni Mazar — El Bhnsa",
        "slug": "beni-mazar-el-bhnsa"
      },
      {
        "name": "Beni Mazar — Nzla Bid",
        "slug": "beni-mazar-nzla-bid"
      },
      {
        "name": "Deir Mawas",
        "slug": "deir-mawas"
      },
      {
        "name": "Deir Mawas — Tl Mran Beni",
        "slug": "deir-mawas-tl-mran-beni"
      },
      {
        "name": "El Doa",
        "slug": "el-doa"
      },
      {
        "name": "El Doa — Rb El Zina",
        "slug": "el-doa-rb-el-zina"
      },
      {
        "name": "Maghagha",
        "slug": "maghagha"
      },
      {
        "name": "Maghagha — Badshar",
        "slug": "maghagha-badshar"
      },
      {
        "name": "Maghagha — Sharona",
        "slug": "maghagha-sharona"
      },
      {
        "name": "Matai",
        "slug": "matai"
      },
      {
        "name": "Matai — Hloa",
        "slug": "matai-hloa"
      },
      {
        "name": "Mloi",
        "slug": "mloi"
      },
      {
        "name": "Mloi — Dir Hns Abu",
        "slug": "mloi-dir-hns-abu"
      },
      {
        "name": "Mloi — Tnda",
        "slug": "mloi-tnda"
      },
      {
        "name": "Samalut",
        "slug": "samalut"
      },
      {
        "name": "Samalut — Astal",
        "slug": "samalut-astal"
      },
      {
        "name": "Samalut — Shtora",
        "slug": "samalut-shtora"
      }
    ]
  },
  {
    "name": "Assiut",
    "slug": "assiut",
    "areas": [
      {
        "name": "Abnoub",
        "slug": "abnoub"
      },
      {
        "name": "Asiot El Gdida",
        "slug": "asiot-el-gdida"
      },
      {
        "name": "Dirot",
        "slug": "dirot"
      },
      {
        "name": "El Qosia",
        "slug": "el-qosia"
      },
      {
        "name": "Manfalut",
        "slug": "manfalut"
      },
      {
        "name": "Sahel Selim",
        "slug": "sahel-selim"
      },
      {
        "name": "Tig Abu",
        "slug": "tig-abu"
      }
    ]
  },
  {
    "name": "Sohag",
    "slug": "sohag",
    "areas": [
      {
        "name": "Akhmim",
        "slug": "akhmim"
      },
      {
        "name": "Al-Balyana",
        "slug": "al-balyana"
      },
      {
        "name": "Al-Maragha",
        "slug": "al-maragha"
      },
      {
        "name": "Dar El-Salam",
        "slug": "dar-el-salam"
      },
      {
        "name": "El Manshaat",
        "slug": "el-manshaat"
      },
      {
        "name": "Ghina",
        "slug": "ghina"
      },
      {
        "name": "Girga",
        "slug": "girga"
      },
      {
        "name": "Sohag El Gdida",
        "slug": "sohag-el-gdida"
      }
    ]
  },
  {
    "name": "Qena",
    "slug": "qena",
    "areas": [
      {
        "name": "Dishna",
        "slug": "dishna"
      },
      {
        "name": "El Oqf",
        "slug": "el-oqf"
      },
      {
        "name": "Farshut",
        "slug": "farshut"
      },
      {
        "name": "Hmadi Nagaa",
        "slug": "hmadi-nagaa"
      },
      {
        "name": "Naqada",
        "slug": "naqada"
      },
      {
        "name": "Qift",
        "slug": "qift"
      },
      {
        "name": "Qna El Gdida",
        "slug": "qna-el-gdida"
      },
      {
        "name": "Qus",
        "slug": "qus"
      },
      {
        "name": "Tsht Abu",
        "slug": "tsht-abu"
      }
    ]
  },
  {
    "name": "Luxor",
    "slug": "luxor",
    "areas": [
      {
        "name": "Al-Qurna",
        "slug": "al-qurna"
      },
      {
        "name": "Al-Zaeinia",
        "slug": "al-zaeinia"
      },
      {
        "name": "Armant",
        "slug": "armant"
      },
      {
        "name": "El Aqsr El Gdida",
        "slug": "el-aqsr-el-gdida"
      },
      {
        "name": "El Aqsr Idaria Sm",
        "slug": "el-aqsr-idaria-sm"
      },
      {
        "name": "El Biadia",
        "slug": "el-biadia"
      },
      {
        "name": "El Tod",
        "slug": "el-tod"
      },
      {
        "name": "Esna",
        "slug": "esna"
      }
    ]
  },
  {
    "name": "Aswan",
    "slug": "aswan",
    "areas": [
      {
        "name": "Ambo Kom",
        "slug": "ambo-kom"
      },
      {
        "name": "Aswaan El Gdida",
        "slug": "aswaan-el-gdida"
      },
      {
        "name": "Drao",
        "slug": "drao"
      },
      {
        "name": "Edfu",
        "slug": "edfu"
      },
      {
        "name": "El Siahia Smbl Abu",
        "slug": "el-siahia-smbl-abu"
      },
      {
        "name": "Nasr al-Nuba",
        "slug": "nasr-al-nuba"
      }
    ]
  },
  {
    "name": "New Valley",
    "slug": "new-valley",
    "areas": [
      {
        "name": "Balat.",
        "slug": "balat"
      },
      {
        "name": "Baris",
        "slug": "baris"
      },
      {
        "name": "El Frafra",
        "slug": "el-frafra"
      },
      {
        "name": "El Kharga El Waahat Mrakzmdn",
        "slug": "el-kharga-el-waahat-mrakzmdn"
      },
      {
        "name": "Mut",
        "slug": "mut"
      }
    ]
  },
  {
    "name": "North Coast",
    "slug": "north-coast",
    "areas": []
  }
] as City[];
